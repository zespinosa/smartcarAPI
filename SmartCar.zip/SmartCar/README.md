# SmartCar API 

This short project follows the SmartCar Interview API Specification. The goal of this API is to create a more friendly user experience for those wishing to use the GMI API.
Testing is completed using Postman. The server is written using Javascript, NodeJS, and Express.

## Getting Started

Download all files. Execute node server.js to run locally.

Visit https://documenter.getpostman.com/view/5027046/RWThUgeV to see POSTMAN tests. 
